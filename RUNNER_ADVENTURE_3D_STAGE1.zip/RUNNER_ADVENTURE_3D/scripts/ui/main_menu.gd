extends Control
## First-stage Arabic menu shell. Gameplay scene is added in Stage 2–4.

const BG := Color("#172b3b")
const GOLD := Color("#f5bd4f")
const CREAM := Color("#fff1d0")

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	var background := ColorRect.new()
	background.color = BG
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var decor := ColorRect.new()
	decor.color = Color("#c87935")
	decor.anchor_left = 0.0
	decor.anchor_top = 0.72
	decor.anchor_right = 1.0
	decor.anchor_bottom = 1.0
	add_child(decor)

	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_CENTER)
	root.position = Vector2(-280, -330)
	root.size = Vector2(560, 660)
	root.add_theme_constant_override("separation", 22)
	add_child(root)

	var title := Label.new()
	title.text = "مغامرة العداء ٣D"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 46)
	title.add_theme_color_override("font_color", GOLD)
	root.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "اركض، اقفز، واجمع الكنوز!"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 25)
	subtitle.add_theme_color_override("font_color", CREAM)
	root.add_child(subtitle)

	var spacer := Control.new()
	spacer.custom_minimum_size.y = 80
	root.add_child(spacer)

	_add_button(root, "ابدأ المغامرة", _on_play_pressed, true)
	_add_button(root, "المتجر", _show_notice, false)
	_add_button(root, "المهام والإنجازات", _show_notice, false)
	_add_button(root, "الإعدادات", _show_notice, false)

	var best := Label.new()
	best.text = "أفضل نتيجة: %s" % str(GameState.profile.get("best_score", 0))
	best.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	best.add_theme_font_size_override("font_size", 21)
	best.add_theme_color_override("font_color", CREAM)
	root.add_child(best)

func _add_button(parent: VBoxContainer, caption: String, callback: Callable, primary: bool) -> void:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(0, 72)
	button.add_theme_font_size_override("font_size", 27 if primary else 23)
	button.add_theme_color_override("font_color", Color("#2b2630") if primary else CREAM)
	var normal := StyleBoxFlat.new()
	normal.bg_color = GOLD if primary else Color("#30485a")
	normal.set_corner_radius_all(18)
	normal.content_margin_left = 16
	normal.content_margin_right = 16
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", normal)
	button.pressed.connect(callback)
	parent.add_child(button)

func _on_play_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/main/game.tscn")

func _show_notice() -> void:
	var dialog := AcceptDialog.new()
	dialog.title = "قريباً"
	dialog.dialog_text = "سيتم تفعيل هذه الميزة ضمن مراحل التطوير التالية."
	add_child(dialog)
	dialog.popup_centered()
